# First program in python
print "welcome to Python!"
